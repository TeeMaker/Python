sor = 0

while sor != 25:
	oszlop = 0
	while oszlop != sor + 1:
		print('O', end='')
		oszlop += 1
	print('')
	sor += 1

sor -= 1

while sor != 0:
	oszlop = 0
	while oszlop != sor:
		print('O', end='')
		oszlop += 1
	print('')
	sor -=1
