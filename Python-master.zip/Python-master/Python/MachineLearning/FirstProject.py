import sklearn
print('sklearn: {}'.format(sklearn.__version__))
