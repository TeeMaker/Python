#number = input('Mekkora haromszoget akarsz csinalni?(Szam)')
#number = int(number)
sor = 0
v = 0
while v != 10:
	while sor != 25:
        	oszlop = 0
        	while oszlop != sor + 1:
                	print(' ', end='')
                	oszlop += 1
        	print('O')
        	sor += 1
	v += 1
