import os
print(os.name)
